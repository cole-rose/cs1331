public Class Student {

    private int mealSwipes;
    private double diningDollars;
    private double BuzzFunds;

    public Student(int mealSwipes, double diningDollars, double BuzzFunds){
        setMealSwipes(mealSwipes);
        setDiningDollars(diningDollars);
        setBuzzFunds(BuzzFunds);
    }

    public void setMealSwipes(int mealSwipes){
        this.mealSwipes = mealSwipes;
    }
    public void setDiningDollars(double diningDollars)
    {
        this.diningDollars = diningDollars;
    }
    public void setBuzzFunds(double BuzzFunds) {
        this.BuzzFunds = BuzzFunds;
    }
    public int getMealSwipes(){
        return this.mealSwipes;
    }
    public double getDiningDollars() {
        return this.diningDollars;
    }
    public double getBuzzFunds(){
        return this.BuzzFunds;
    }
}