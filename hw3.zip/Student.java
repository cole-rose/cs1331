public class Student {
    private BuzzCard card;



}